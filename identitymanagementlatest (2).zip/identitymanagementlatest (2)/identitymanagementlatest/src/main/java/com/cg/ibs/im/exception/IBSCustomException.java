package com.cg.ibs.im.exception;

public class IBSCustomException extends Exception {

	public IBSCustomException(String message) {
		System.out.println(message);
	}
}
